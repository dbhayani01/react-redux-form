import { useEffect, useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { handleChange } from '../actions';
import { useSelector } from 'react-redux';
import PreviewForm from './PreviewForm';
import store from '../store';
function DynamicForm() {
    const [validated, setValidated] = useState(false);
    
    let dispatch = useDispatch();
    let data = useSelector((state)=>state.setData)
    
    return (
        <>
        <Form className='dynamic-form' noValidate validated={validated} >
            <h5>Dynamic Form</h5> <br />
            {data ? data.map((item) => (
                item !== null ?
                    <Form.Group className="mb-3" controlId={item.id}>
                        <Form.Label>{item.label}</Form.Label>
                        <div style={{ display: "flex", padding: "5px" }}>
                            {"radio" === item.type ?

                                item.options.map((opt) => (
                                    <Form.Check
                                        required={item.validations ? item.validations.map((val) => {
                                            if (val.type === "required") {
                                                return true;
                                            }
                                        })
                                            : false}
                                        type={item.type}
                                        name={item.label}
                                        label={opt.label}
                                        value = {opt.value}
                                        onChange={(e) => dispatch(handleChange(e))}
                                    />))

                                : "select" === item.type ?
                                    <Form.Select
                                        required={item.validations ? item.validations.map((val) => {
                                            if (val.type === "required") {
                                                return true;
                                            }
                                        })
                                            : false}
                                        onSelect={(e) => dispatch(handleChange(e))} aria-label="Default select example">
                                        {item.options.map((sel) => (
                                            <option value={sel.label}>{sel.label}</option>
                                        ))}
                                    </Form.Select>
                                    : <Form.Control
                                        required={item.validations ? item.validations.map((val) => {
                                            if (val.type === "required") {
                                                return true;
                                            }
                                        })
                                            : false}
                                        onChange={(e) => dispatch(handleChange(e))}
                                        type={item.type}
                                        placeholder={item.placeholder} />}
                        </div>
                         <Form.Control.Feedback type="invalid">Looks good!</Form.Control.Feedback>
                    </Form.Group>
                    
                     : false)) : <></>}
            <Button type="button" onClick={()=>setValidated(true)}>Preview form</Button>
        </Form>
        <PreviewForm data ={data}/>
        </>
    );
}

export default DynamicForm;