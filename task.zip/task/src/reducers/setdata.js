import data from "../data.json"

const handleChange = (state,payload) =>{
    
    state.map((item,ind)=>{
         if(item!==null)
         {
            if(item.id === payload.target.id)
            {
                state[ind]["fvalue"] = payload.target.value;
            }
         }
    })
    console.log(state);
    return state;
}

export const setData = (state = data , action) => {
    switch(action.type){
        case "hChange" : return handleChange(state,action.payload);
        default : return state;
    }
}