// import { Form, Button } from 'react-bootstrap';
import './App.css';
import DynamicForm from './components/DynamicForm';
import PreviewForm from './components/PreviewForm';
import { useSelector } from 'react-redux';
function App() {
  
  return (
    <div className='App'>
      <DynamicForm />
      {/* <PreviewForm/> */}
    </div>
  );
}

export default App;