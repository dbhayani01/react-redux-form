export const  setData = (payload) => {
    return {
        type: "Change",
        payload : payload
    }
}

export const handleChange = (payload) =>{
    return {
        type : "hChange",
        payload : payload
    }
}