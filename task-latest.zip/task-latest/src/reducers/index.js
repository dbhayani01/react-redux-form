import { combineReducers } from "redux";
import { setData } from "./setdata";

const rootReducer = combineReducers({
        setData
})

export default rootReducer;