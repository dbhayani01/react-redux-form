import data from "../data.json"

const ChangeS = (state,payload) =>{
    
    state.map((item,ind)=>{
         if(item!==null)
         {
            if(item.id === payload.target.id)
            {
                state[ind]["fvalue"] = payload.target.value;
                
            }
         }
    })
    return state;
}

export const setData = (state = data , action) => {
    switch(action.type){
        case "hChange" : return ChangeS(state,action.payload);
        default : return state;
    }
}