import { useEffect, useState } from 'react';
import { Form, Button } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { handleChange } from '../actions';
import { useSelector } from 'react-redux';
import PreviewForm from './PreviewForm';
import { type } from '@testing-library/user-event/dist/type';
// import store from '../store';
function DynamicForm() {
    const [validated, setValidated] = useState(false);
    const [preview, setPreview] = useState(false);
    let dispatch = useDispatch();
    let data = useSelector((state) => state.setData)
    // const [valid,setValid] = useState(true);

    const handleValidation = () => {
        let valid = true;
        data.map((item) => {
            item?.validations?.map((val) => {

                if (Object.keys(item).includes("fvalue")) {
                    if (item.validationType === "string") {
                        if (val.type === 'required' && item.fvalue.value === 0) {
                            valid = false;
                            console.log(val.params[0])
                        }
                        else if (val.type === "min" && item.fvalue.length < val.params[0]) {
                            valid = false;
                            console.log(val.params[1])
                        }
                        else if (val.type === "max" && item.fvalue.length > val.params[0]) {
                            valid = false;
                            console.log(val.params[1])
                        }
                    }
                    else if(item.validationType === "number")
                    {
                        if (val.type === 'required' && item.fvalue.value === 0) {
                            valid = false;
                            console.log(val.params[0])
                        }
                        else if (val.type === "min" && item.fvalue.length < val.params[0]) {
                            valid = false;
                            console.log(val.params[1])
                        }
                        else if (val.type === "max" && item.fvalue.length > val.params[0]) {
                            valid = false;
                            console.log(val.params[1])
                        }
                    }
                    else if (item.validationType === "email") {
                        let ev = String(item.fvalue)
                            .toLowerCase()
                            .match(
                                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                            );
                        if(!ev)
                        {
                            console.log(val.params[0])
                        }
                    }
                    else{
                        if (val.type === 'required' && item.fvalue.value === 0) {
                            valid = false;
                            console.log(val.params[0])
                        }
                    }
                }
                else {
                    valid = false;
                    console.log(val.params[0])
                }
            })
        })
        setValidated(true);
        if (valid) {
            setPreview(true);
        }
    }
    return (
        <>
            <Form className='dynamic-form' noValidate validated={validated}  >
                <h5>Dynamic Form</h5> <br />
                {data ? data.map((item) => (
                    item !== null ?
                        <Form.Group className="mb-3" controlId={item.id}>
                            <Form.Label>{item.label}</Form.Label>
                            <div style={{ display: "flex", padding: "5px" }}>
                                {"radio" === item.type ?

                                    item.options.map((opt) => (
                                        <Form.Check
                                            required={item.validations ? item.validations.map((val) => {
                                                if (val.type === "required") {
                                                    return true;
                                                }
                                            })
                                                : false}
                                            type={item.type}
                                            name={item.label}
                                            label={opt.label}
                                            value={opt.value}
                                            onChange={(e) => dispatch(handleChange(e))}
                                        />))

                                    : "select" === item.type ?
                                        <Form.Select
                                            required={item.validations ? item.validations.map((val) => {
                                                if (val.type === "required") {
                                                    return true;
                                                }
                                            })
                                                : false}
                                            onClick={(e) => dispatch(handleChange(e))} aria-label="Default select example">
                                            {item.options.map((sel) => (
                                                <option value={sel.label}>{sel.label}</option>
                                            ))}
                                        </Form.Select>
                                        : <Form.Control
                                            required={item.validations ? item.validations.map((val) => {
                                                if (val.type === "required") {
                                                    return true;
                                                }
                                            })
                                                : false}
                                            onChange={(e) => dispatch(handleChange(e))}
                                            type={item.type}
                                            placeholder={item.placeholder} />}
                            </div>
                            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                        </Form.Group>

                        : false)) : <></>}
                <Button type="button" onClick={() => handleValidation()}>Preview form</Button>
            </Form>
            {preview && <PreviewForm />}
        </>
    );
}

export default DynamicForm;