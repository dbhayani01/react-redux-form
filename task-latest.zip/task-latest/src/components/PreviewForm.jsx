
import { Form } from 'react-bootstrap';
import { useSelector } from 'react-redux';



function PreviewForm() {
    //  const [data,setData] = useState([])
     let data = useSelector((state) =>state.setData)
    // store.subscribe(()=>{
    //     data = store.getState()
    // })
    // useEffect(()=>{console.log("data changed")},[])
    return (
        <Form className='preview-form'>
            <h5>Preview Form</h5> <br />
            {data ? data.map((item) => (
                item !== null ?
                    <Form.Group className="mb-3" controlId={item.id}>
                        <Form.Label>{item.label}</Form.Label>
                        <div style={{display:"flex",padding:"5px"}}>
                        {"radio" === item.type ?
                            
                            item.options.map((opt) => (
                                <Form.Check disabled
                                       type={item.type}
                                        name= {item.label}
                                        label={opt.label}
                                        checked={item.fvalue?item.fvalue === opt.value:false}
                                    />))
                            
                            // : "select" === item.type ?
                            //     <Form.Select disabled  value = {item.fvalue} aria-label="Default select example"/>
                                    
                                
                                : <Form.Control disabled type={item.type} defaultValue={item.fvalue?item.fvalue:item.placeholder} />}
                        </div>
                    </Form.Group> : false)) : <></>}
        </Form>
    );
}

export default PreviewForm;