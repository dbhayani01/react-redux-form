export const handleChange = (payload) =>{
    return {
        type : "hChange",
        payload : payload
    }
}